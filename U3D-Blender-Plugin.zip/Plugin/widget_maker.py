import bpy
import os
import json
import shutil


def ensure_image_emission_nodes(obj):
    if not obj.data.materials:
        obj.data.materials.append(bpy.data.materials.new("sheet_mat"))

    mat = obj.data.materials[0]
    mat.use_nodes = True

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    def get(type_name):
        for n in nodes:
            if n.type == type_name:
                return n
        return None

    image_node = get("TEX_IMAGE") or nodes.new("ShaderNodeTexImage")
    emission = get("EMISSION") or nodes.new("ShaderNodeEmission")
    transparent = get("BSDF_TRANSPARENT") or nodes.new("ShaderNodeBsdfTransparent")
    mix = get("MIX_SHADER") or nodes.new("ShaderNodeMixShader")
    out = get("OUTPUT_MATERIAL") or nodes.new("ShaderNodeOutputMaterial")

    for l in list(links):
        if l.to_node == out and l.to_socket.name == "Surface":
            links.remove(l)

    links.new(image_node.outputs["Color"], emission.inputs["Color"])
    links.new(image_node.outputs["Alpha"], mix.inputs["Fac"])
    links.new(transparent.outputs["BSDF"], mix.inputs[1])
    links.new(emission.outputs["Emission"], mix.inputs[2])
    links.new(mix.outputs["Shader"], out.inputs["Surface"])

    mat.blend_method = "BLEND"
    return image_node


def unwrap_from_view(obj_name, camera_name):
    bpy.context.view_layer.objects.active = bpy.data.objects[obj_name]
    bpy.context.scene.camera = bpy.data.objects[camera_name]

    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')

    for window in bpy.context.window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        context_override = bpy.context.copy()
                        override = {
                            'window': window,
                            'screen': screen,
                            'area': area,
                            'region': region,
                            'scene': bpy.context.scene,
                            'edit_object': bpy.context.edit_object,
                            'active_object': bpy.context.active_object,
                            'selected_objects': bpy.context.selected_objects,
                        }
                        context_override.update(override)
                        with bpy.context.temp_override(**context_override):
                            bpy.ops.uv.project_from_view(
                                camera_bounds=True,
                                correct_aspect=False,
                                scale_to_bounds=False,
                            )

    bpy.ops.object.mode_set(mode='OBJECT')


def render_still(cam, frame, path, output_format="PNG"):
    scene = bpy.context.scene
    prev_cam = scene.camera
    prev_fp = scene.render.filepath
    prev_fmt = scene.render.image_settings.file_format
    prev_mode = scene.render.image_settings.color_mode

    try:
        scene.camera = cam
        scene.frame_set(frame)
        scene.render.filepath = path
        if output_format == 'JPG':
            scene.render.image_settings.file_format = "JPEG"
            scene.render.image_settings.color_mode = "RGB"
        else:
            scene.render.image_settings.file_format = "PNG"
            scene.render.image_settings.color_mode = "RGBA"
        os.makedirs(os.path.dirname(path), exist_ok=True)
        bpy.ops.render.render(write_still=True)
    finally:
        scene.camera = prev_cam
        scene.render.filepath = prev_fp
        scene.render.image_settings.file_format = prev_fmt
        scene.render.image_settings.color_mode = prev_mode


def run_generator(json_path, output_format="PNG"):
    with open(json_path, 'r') as f:
        data = json.load(f)
    components = data['components']

    start_frame = 0
    end_frame = 40

    PROJ_CAMERA_NAME = "Camera3"
    FINAL_CAMERA_NAME = "Camera2"
    OBJECT_NAME = "SHEET"

    ext = ".png" if output_format == "PNG" else ".jpg"

    json_dir = os.path.dirname(os.path.abspath(json_path))

    for component in components:
        print(f"Rendering component: {component['name']}")
        output_folder = os.path.join(json_dir, component['folder'])
        if not os.path.exists(output_folder):
            os.makedirs(output_folder)

        temp_folder = os.path.join(output_folder, "temp_proj")
        if not os.path.exists(temp_folder):
            os.makedirs(temp_folder)

        scene_collection = bpy.data.collections.get("SCENE")
        if scene_collection:
            for obj in scene_collection.objects:
                obj.hide_render = obj.name not in component['objects']

        sheet_obj = bpy.data.objects.get(OBJECT_NAME)
        proj_cam = bpy.data.objects.get(PROJ_CAMERA_NAME)
        final_cam = bpy.data.objects.get(FINAL_CAMERA_NAME)
        scene_collection = bpy.data.collections.get("SCENE")

        if not sheet_obj or not proj_cam or not final_cam:
            raise RuntimeError("Missing Object or Camera (SHEET, Camera3, or Camera2)")

        image_node = ensure_image_emission_nodes(sheet_obj)

        for frame in range(start_frame, end_frame + 1):
            if bpy.context.scene.unchained_stop_render:
                print("Stop requested. Aborting widget render.")
                return

            print(f"Rendering Frame {frame} for {component['name']}...")
            bpy.context.scene.frame_set(frame)

            sheet_obj.hide_render = True
            if scene_collection:
                scene_collection.hide_render = False

            temp_path = os.path.join(temp_folder, f"proj_{frame:04d}.png")
            render_still(proj_cam, frame, temp_path, output_format=output_format)

            sheet_obj.hide_render = False

            try:
                loaded_img = None
                for im in bpy.data.images:
                    if im.filepath == temp_path or os.path.abspath(bpy.path.abspath(im.filepath)) == os.path.abspath(temp_path):
                        loaded_img = im
                        break

                if loaded_img is None:
                    loaded_img = bpy.data.images.load(temp_path)
                else:
                    loaded_img.reload()

                image_node.image = loaded_img
            except Exception as e:
                print(f"Error loading temp image: {e}")

            unwrap_from_view(OBJECT_NAME, PROJ_CAMERA_NAME)

            if scene_collection:
                scene_collection.hide_render = True

            out_path = os.path.join(output_folder, f"RENDER_{frame:03d}{ext}")
            render_still(final_cam, frame, out_path, output_format=output_format)

            if scene_collection:
                scene_collection.hide_render = False
            sheet_obj.hide_render = True

            yield

        if os.path.exists(temp_folder):
            shutil.rmtree(temp_folder)

    print("Frame Rendering Done.")


def run(json_path, output_format="PNG"):
    gen = run_generator(json_path, output_format)
    try:
        while True:
            next(gen)
    except StopIteration:
        pass
