import bpy
import os

from . import widget_maker
from . import single_3d
from . import video_3d
from . import image_shrink
from . import compat


bl_info = {
    "name": "UNCHAINED3D Renderer",
    "author": "UNCHAINED3D",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > UNCHAINED3D",
    "description": "Render tools for widget sheets, single 3D projections, and multi-angle 3D video.",
    "category": "Render",
}


class UNCHAINED3D_OT_stop(bpy.types.Operator):
    bl_idname = "unchained3d.stop"
    bl_label = "Stop Render"
    bl_description = "Stop the current render"

    def execute(self, context):
        context.scene.unchained_stop_render = True
        self.report({'WARNING'}, "Stop requested.")
        return {'FINISHED'}


class UNCHAINED3D_OT_widget_render(bpy.types.Operator):
    bl_idname = "unchained3d.widget_render"
    bl_label = "Render Widgets"
    bl_description = "Render widgets from widget_components.json"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _generator = None

    json_path: bpy.props.StringProperty(
        name="JSON File",
        description="Path to widget_components.json",
        subtype='FILE_PATH',
    )

    def execute(self, context):
        json_path = bpy.path.abspath(context.scene.unchained_json_path)
        if not json_path or not os.path.exists(json_path):
            self.report({'ERROR'}, "JSON file not found. Set a valid path first.")
            return {'CANCELLED'}

        context.scene.unchained_stop_render = False
        self._generator = widget_maker.run_generator(
            json_path,
            context.scene.unchained_output_format,
            enable_shrink=context.scene.unchained_enable_shrink,
        )
        try:
            next(self._generator)
        except StopIteration:
            self.report({'INFO'}, "Widget rendering complete.")
            self._cleanup(context)
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, str(e))
            self._cleanup(context)
            return {'CANCELLED'}

        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'TIMER':
            if context.scene.unchained_stop_render:
                self.report({'WARNING'}, "Render stopped.")
                self._cleanup(context)
                return {'CANCELLED'}

            try:
                next(self._generator)
            except StopIteration:
                self.report({'INFO'}, "Widget rendering complete.")
                self._cleanup(context)
                return {'FINISHED'}
            except Exception as e:
                self.report({'ERROR'}, str(e))
                self._cleanup(context)
                return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def cancel(self, context):
        self._cleanup(context)

    def _cleanup(self, context):
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        if self._generator is not None:
            try:
                self._generator.close()
            except Exception:
                pass
        self._generator = None


class UNCHAINED3D_OT_single_render(bpy.types.Operator):
    bl_idname = "unchained3d.single_render"
    bl_label = "Render Single 3D"
    bl_description = "Render single 3D projection frames and MP4"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _generator = None

    output_folder: bpy.props.StringProperty(
        name="Output Folder",
        description="Folder to save renders",
        subtype='DIR_PATH',
    )
    start_frame: bpy.props.IntProperty(
        name="Start Frame",
        default=0,
        min=0,
    )
    end_frame: bpy.props.IntProperty(
        name="End Frame",
        default=120,
        min=0,
    )

    def execute(self, context):
        output_folder = bpy.path.abspath(context.scene.unchained_single_output)
        if not output_folder:
            self.report({'ERROR'}, "Output folder not set.")
            return {'CANCELLED'}

        context.scene.unchained_stop_render = False
        self._generator = single_3d.run_generator(
            output_folder=output_folder,
            start_frame=context.scene.unchained_single_start_frame,
            end_frame=context.scene.unchained_single_end_frame,
            output_format=context.scene.unchained_output_format,
            enable_shrink=context.scene.unchained_enable_shrink,
        )
        try:
            next(self._generator)
        except StopIteration:
            self.report({'INFO'}, "Single 3D rendering complete.")
            self._cleanup(context)
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, str(e))
            self._cleanup(context)
            return {'CANCELLED'}

        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'TIMER':
            if context.scene.unchained_stop_render:
                self.report({'WARNING'}, "Render stopped.")
                self._cleanup(context)
                return {'CANCELLED'}

            try:
                next(self._generator)
            except StopIteration:
                self.report({'INFO'}, "Single 3D rendering complete.")
                self._cleanup(context)
                return {'FINISHED'}
            except Exception as e:
                self.report({'ERROR'}, str(e))
                self._cleanup(context)
                return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def cancel(self, context):
        self._cleanup(context)

    def _cleanup(self, context):
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        if self._generator is not None:
            try:
                self._generator.close()
            except Exception:
                pass
        self._generator = None


class UNCHAINED3D_OT_video_render(bpy.types.Operator):
    bl_idname = "unchained3d.video_render"
    bl_label = "Render 3D Video"
    bl_description = "Render multi-angle 3D video frames and MP4s"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _generator = None

    base_output_dir: bpy.props.StringProperty(
        name="Output Folder",
        description="Base output folder",
        subtype='DIR_PATH',
    )
    start_frame: bpy.props.IntProperty(
        name="Start Frame",
        default=1,
        min=0,
    )
    end_frame: bpy.props.IntProperty(
        name="End Frame",
        default=89,
        min=0,
    )
    start_angle_deg: bpy.props.FloatProperty(
        name="Start Angle",
        default=20.0,
    )
    end_angle_deg: bpy.props.FloatProperty(
        name="End Angle",
        default=-20.0,
    )
    total_angle_steps: bpy.props.IntProperty(
        name="Angle Steps",
        default=21,
        min=1,
    )
    restart_point: bpy.props.IntProperty(
        name="Restart Point",
        default=0,
        min=0,
    )

    def execute(self, context):
        context.scene.unchained_stop_render = False
        base_output_dir = bpy.path.abspath(context.scene.unchained_video_output)
        if not base_output_dir:
            self.report({'ERROR'}, "Output folder not set.")
            return {'CANCELLED'}

        self._generator = video_3d.run_generator(
            base_output_dir=base_output_dir,
            start_frame=context.scene.unchained_video_start_frame,
            end_frame=context.scene.unchained_video_end_frame,
            start_angle_deg=context.scene.unchained_video_start_angle,
            end_angle_deg=context.scene.unchained_video_end_angle,
            total_angle_steps=context.scene.unchained_video_angle_steps,
            restart_point=context.scene.unchained_video_restart,
            output_format=context.scene.unchained_output_format,
            enable_shrink=context.scene.unchained_enable_shrink,
        )
        try:
            next(self._generator)
        except StopIteration:
            self.report({'INFO'}, "3D Video rendering complete.")
            self._cleanup(context)
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, str(e))
            self._cleanup(context)
            return {'CANCELLED'}

        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'TIMER':
            if context.scene.unchained_stop_render:
                self.report({'WARNING'}, "Render stopped.")
                self._cleanup(context)
                return {'CANCELLED'}

            try:
                next(self._generator)
            except StopIteration:
                self.report({'INFO'}, "3D Video rendering complete.")
                self._cleanup(context)
                return {'FINISHED'}
            except Exception as e:
                self.report({'ERROR'}, str(e))
                self._cleanup(context)
                return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def cancel(self, context):
        self._cleanup(context)

    def _cleanup(self, context):
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        if self._generator is not None:
            try:
                self._generator.close()
            except Exception:
                pass
        self._generator = None


class UNCHAINED3D_PT_main_panel(bpy.types.Panel):
    bl_label = "UNCHAINED3D"
    bl_idname = "UNCHAINED3D_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "UNCHAINED3D"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.prop(scene, "unchained_enable_shrink")

        layout.label(text="Widget Maker", icon='FILE_IMAGE')
        box = layout.box()
        box.prop(scene, "unchained_json_path")
        box.prop(scene, "unchained_output_format", text="Image Format")
        box.operator("unchained3d.widget_render", icon='RENDER_STILL')
        box.operator("unchained3d.stop", icon='CANCEL')

        layout.label(text="Single 3D", icon='RENDER_STILL')
        box = layout.box()
        box.prop(scene, "unchained_single_output")
        box.prop(scene, "unchained_single_start_frame")
        box.prop(scene, "unchained_single_end_frame")
        box.prop(scene, "unchained_output_format", text="Image Format")
        box.operator("unchained3d.single_render", icon='RENDER_STILL')
        box.operator("unchained3d.stop", icon='CANCEL')

        layout.label(text="3D Video", icon='RENDER_ANIMATION')
        box = layout.box()
        box.prop(scene, "unchained_video_output")
        box.prop(scene, "unchained_video_start_frame")
        box.prop(scene, "unchained_video_end_frame")
        box.prop(scene, "unchained_video_start_angle")
        box.prop(scene, "unchained_video_end_angle")
        box.prop(scene, "unchained_video_angle_steps")
        box.prop(scene, "unchained_video_restart")
        box.prop(scene, "unchained_output_format", text="Image Format")
        box.operator("unchained3d.video_render", icon='RENDER_ANIMATION')
        box.operator("unchained3d.stop", icon='CANCEL')


classes = (
    UNCHAINED3D_OT_stop,
    UNCHAINED3D_OT_widget_render,
    UNCHAINED3D_OT_single_render,
    UNCHAINED3D_OT_video_render,
    UNCHAINED3D_PT_main_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.unchained_json_path = bpy.props.StringProperty(
        name="JSON File",
        description="Path to widget_components.json",
        subtype='FILE_PATH',
        default="",
    )
    bpy.types.Scene.unchained_single_output = bpy.props.StringProperty(
        name="Output Folder",
        description="Folder to save single 3D renders",
        subtype='DIR_PATH',
        default="",
    )
    bpy.types.Scene.unchained_single_start_frame = bpy.props.IntProperty(
        name="Start Frame",
        default=0,
        min=0,
    )
    bpy.types.Scene.unchained_single_end_frame = bpy.props.IntProperty(
        name="End Frame",
        default=120,
        min=0,
    )
    bpy.types.Scene.unchained_video_output = bpy.props.StringProperty(
        name="Output Folder",
        description="Base output folder for 3D video",
        subtype='DIR_PATH',
        default="",
    )
    bpy.types.Scene.unchained_video_start_frame = bpy.props.IntProperty(
        name="Start Frame",
        default=1,
        min=0,
    )
    bpy.types.Scene.unchained_video_end_frame = bpy.props.IntProperty(
        name="End Frame",
        default=89,
        min=0,
    )
    bpy.types.Scene.unchained_video_start_angle = bpy.props.FloatProperty(
        name="Start Angle",
        default=20.0,
    )
    bpy.types.Scene.unchained_video_end_angle = bpy.props.FloatProperty(
        name="End Angle",
        default=-20.0,
    )
    bpy.types.Scene.unchained_video_angle_steps = bpy.props.IntProperty(
        name="Angle Steps",
        default=21,
        min=1,
    )
    bpy.types.Scene.unchained_video_restart = bpy.props.IntProperty(
        name="Restart Point",
        default=0,
        min=0,
    )
    bpy.types.Scene.unchained_output_format = bpy.props.EnumProperty(
        name="Image Format",
        description="Output image format for frame renders",
        items=[
            ('PNG', "PNG (RGBA)", "Output PNG with alpha channel"),
            ('JPG', "JPG (RGB)", "Output JPG without alpha"),
        ],
        default='PNG',
    )
    bpy.types.Scene.unchained_enable_shrink = bpy.props.BoolProperty(
        name="Shrink Images After Render",
        description="Re-save rendered images with better compression to shrink file size (same resolution)",
        default=True,
    )
    bpy.types.Scene.unchained_stop_render = bpy.props.BoolProperty(
        name="Stop Render",
        description="Signal to stop the current render",
        default=False,
    )


def unregister():
    del bpy.types.Scene.unchained_json_path
    del bpy.types.Scene.unchained_single_output
    del bpy.types.Scene.unchained_single_start_frame
    del bpy.types.Scene.unchained_single_end_frame
    del bpy.types.Scene.unchained_video_output
    del bpy.types.Scene.unchained_video_start_frame
    del bpy.types.Scene.unchained_video_end_frame
    del bpy.types.Scene.unchained_video_start_angle
    del bpy.types.Scene.unchained_video_end_angle
    del bpy.types.Scene.unchained_video_angle_steps
    del bpy.types.Scene.unchained_video_restart
    del bpy.types.Scene.unchained_output_format
    del bpy.types.Scene.unchained_enable_shrink
    del bpy.types.Scene.unchained_stop_render

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
