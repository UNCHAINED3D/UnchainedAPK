import bpy
import os
import math


def ensure_image_emission_nodes(obj):
    if not obj.data.materials:
        obj.data.materials.append(bpy.data.materials.new("sheet_mat"))

    mat = obj.data.materials[0]
    mat.use_nodes = True

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    def get(type_name):
        for n in nodes:
            if n.type == type_name:
                return n
        return None

    image_node = get("TEX_IMAGE") or nodes.new("ShaderNodeTexImage")
    emission = get("EMISSION") or nodes.new("ShaderNodeEmission")
    transparent = get("BSDF_TRANSPARENT") or nodes.new("ShaderNodeBsdfTransparent")
    mix = get("MIX_SHADER") or nodes.new("ShaderNodeMixShader")
    out = get("OUTPUT_MATERIAL") or nodes.new("ShaderNodeOutputMaterial")

    for l in list(links):
        if l.to_node == out and l.to_socket.name == "Surface":
            links.remove(l)

    links.new(image_node.outputs["Color"], emission.inputs["Color"])
    links.new(image_node.outputs["Alpha"], mix.inputs["Fac"])
    links.new(transparent.outputs["BSDF"], mix.inputs[1])
    links.new(emission.outputs["Emission"], mix.inputs[2])
    links.new(mix.outputs["Shader"], out.inputs["Surface"])

    mat.blend_method = "BLEND"
    return image_node


def unwrap_from_view(obj_name, camera_name):
    bpy.context.view_layer.objects.active = bpy.data.objects[obj_name]
    bpy.context.scene.camera = bpy.data.objects[camera_name]

    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')

    for window in bpy.context.window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        context_override = bpy.context.copy()
                        override = {
                            'window': window,
                            'screen': screen,
                            'area': area,
                            'region': region,
                            'scene': bpy.context.scene,
                            'edit_object': bpy.context.edit_object,
                            'active_object': bpy.context.active_object,
                            'selected_objects': bpy.context.selected_objects,
                        }
                        context_override.update(override)
                        with bpy.context.temp_override(**context_override):
                            bpy.ops.uv.project_from_view(
                                camera_bounds=True,
                                correct_aspect=False,
                                scale_to_bounds=False,
                            )

    bpy.ops.object.mode_set(mode='OBJECT')


def render_still(cam, frame, path, output_format="PNG"):
    scene = bpy.context.scene
    prev_cam = scene.camera
    prev_fp = scene.render.filepath
    prev_fmt = scene.render.image_settings.file_format

    try:
        scene.camera = cam
        scene.frame_set(frame)
        scene.render.filepath = path
        if output_format == 'JPG':
            scene.render.image_settings.file_format = "JPEG"
            scene.render.image_settings.color_mode = "RGB"
        else:
            scene.render.image_settings.file_format = "PNG"
            scene.render.image_settings.color_mode = "RGBA"
        os.makedirs(os.path.dirname(path), exist_ok=True)
        bpy.ops.render.render(write_still=True)
    finally:
        scene.camera = prev_cam
        scene.render.filepath = prev_fp
        scene.render.image_settings.file_format = prev_fmt


def clear_vse(scene):
    if scene.sequence_editor:
        for s in list(scene.sequence_editor.sequences):
            try:
                scene.sequence_editor.sequences.remove(s)
            except Exception:
                pass


def run_generator(base_output_dir, start_frame, end_frame, start_angle_deg, end_angle_deg,
                  total_angle_steps, output_format="PNG", restart_point=None, codec="H264", format="MPEG4",
                  crf="MEDIUM", preset="GOOD", gop=12, video_bitrate=4500):
    frame_count = end_frame - start_frame + 1

    object_name = "SHEET"
    proj_camera_name = "Camera1"
    final_camera_name = "Camera2"

    ext = ".png" if output_format == "PNG" else ".jpg"

    temp_renders_folder = os.path.join(base_output_dir, "temp_renders")
    angle_frames_root = os.path.join(base_output_dir, "angle_frames")
    final_videos_folder = os.path.join(base_output_dir, "final_videos")

    os.makedirs(temp_renders_folder, exist_ok=True)
    os.makedirs(angle_frames_root, exist_ok=True)
    os.makedirs(final_videos_folder, exist_ok=True)

    scene = bpy.context.scene
    scene.frame_start = start_frame
    scene.frame_end = end_frame

    sheet_obj = bpy.data.objects.get(object_name)
    proj_cam = bpy.data.objects.get(proj_camera_name)
    final_cam = bpy.data.objects.get(final_camera_name)
    scene_collection = bpy.data.collections.get("SCENE")

    if sheet_obj is None:
        raise RuntimeError("SHEET object not found")

    if proj_cam is None or final_cam is None:
        raise RuntimeError("Projection or final camera missing.")

    image_node = ensure_image_emission_nodes(sheet_obj)

    yield

    if total_angle_steps > 1:
        ang_step = (end_angle_deg - start_angle_deg) / (total_angle_steps - 1)
    else:
        ang_step = 0

    angles = [start_angle_deg + i * ang_step for i in range(total_angle_steps)]

    start_i = restart_point if restart_point is not None else 0
    end_i = total_angle_steps

    for idx, ang in enumerate(angles[start_i:end_i]):
        vid_i = start_i + idx

        print(f"\n=== Angle {vid_i:03} — Rot {ang}° ===")

        if "BALL" in bpy.data.objects:
            bpy.data.objects["BALL"].rotation_euler[2] = math.radians(ang)

        angle_dir = os.path.join(angle_frames_root, f"angle_{vid_i:03}")
        os.makedirs(angle_dir, exist_ok=True)

        for f_idx, frm in enumerate(range(start_frame, end_frame + 1)):
            print(f"  Frame {frm} / {end_frame}")

            temp_img = os.path.join(temp_renders_folder, f"temp_{vid_i:03}_{frm:04}.png")
            render_still(proj_cam, frm, temp_img, output_format=output_format)

            sheet_obj.hide_render = False
            sheet_obj.hide_viewport = False
            bpy.context.view_layer.objects.active = sheet_obj
            sheet_obj.select_set(True)

            try:
                loaded_img = None
                for im in bpy.data.images:
                    if im.filepath == temp_img or os.path.abspath(bpy.path.abspath(im.filepath)) == os.path.abspath(temp_img):
                        loaded_img = im
                        break

                if loaded_img is None:
                    loaded_img = bpy.data.images.load(temp_img)
                else:
                    loaded_img.reload()
            except Exception as e:
                print("Failed to load temp image:", e)
                raise

            image_node.image = loaded_img

            try:
                image_node.image_user.use_auto_refresh = True
                image_node.image_user.frame_start = 0
                image_node.image_user.frame_duration = frame_count
            except Exception:
                pass

            unwrap_from_view(object_name, proj_camera_name)

            if scene_collection:
                scene_collection.hide_render = True

            out_frame = os.path.join(angle_dir, f"frame_{f_idx:04}{ext}")
            render_still(final_cam, frm, out_frame, output_format=output_format)

            if scene_collection:
                scene_collection.hide_render = False
            sheet_obj.hide_render = True

            yield

        if scene.unchained_stop_render:
            print("Stop requested. Aborting MP4 build.")
            return

        print(f"  ▶ Building MP4 for angle {vid_i:03}")

        if not scene.sequence_editor:
            scene.sequence_editor_create()

        clear_vse(scene)
        seq = scene.sequence_editor

        first_frame = os.path.join(angle_dir, f"frame_0000{ext}")
        if not os.path.exists(first_frame):
            print("  !! Missing first frame, skipping.")
            continue

        strip = seq.sequences.new_image(
            name=f"Angle_{vid_i:03}",
            filepath=first_frame,
            channel=1,
            frame_start=1,
        )

        while len(strip.elements) > 0:
            try:
                strip.elements.remove(strip.elements[0])
            except Exception:
                break

        for i in range(frame_count):
            strip.elements.append(f"frame_{i:04}{ext}")

        strip.frame_final_duration = frame_count

        scene.render.image_settings.file_format = "FFMPEG"
        scene.render.ffmpeg.format = format
        scene.render.ffmpeg.codec = codec
        scene.render.ffmpeg.constant_rate_factor = crf
        scene.render.ffmpeg.ffmpeg_preset = preset
        scene.render.ffmpeg.gopsize = gop
        scene.render.ffmpeg.video_bitrate = video_bitrate
        scene.render.ffmpeg.audio_codec = "NONE"

        scene.frame_start = 1
        scene.frame_end = frame_count

        out_mp4 = os.path.join(final_videos_folder, f"video_{vid_i:03}.mp4")
        scene.render.filepath = out_mp4

        print(f"  ▶ Rendering MP4 → {out_mp4}")
        bpy.ops.render.render(animation=True)

        clear_vse(scene)

        yield

    print("\n=== DONE ===")
    print("Videos saved to:", final_videos_folder)


def run(base_output_dir, start_frame, end_frame, start_angle_deg, end_angle_deg,
        total_angle_steps, output_format="PNG", restart_point=None, codec="H264", format="MPEG4",
        crf="MEDIUM", preset="GOOD", gop=12, video_bitrate=4500):
    gen = run_generator(
        base_output_dir, start_frame, end_frame, start_angle_deg, end_angle_deg,
        total_angle_steps, output_format, restart_point, codec, format,
        crf, preset, gop, video_bitrate,
    )
    try:
        while True:
            next(gen)
    except StopIteration:
        pass
