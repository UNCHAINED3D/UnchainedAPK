import bpy
import os

try:
    from . import image_shrink
except ImportError:  # running as a loose script
    import image_shrink


def ensure_image_emission_nodes(obj):
    if not obj.data.materials:
        obj.data.materials.append(bpy.data.materials.new("sheet_mat"))

    mat = obj.data.materials[0]
    mat.use_nodes = True

    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    def get(type_name):
        for n in nodes:
            if n.type == type_name:
                return n
        return None

    image_node = get("TEX_IMAGE") or nodes.new("ShaderNodeTexImage")
    emission = get("EMISSION") or nodes.new("ShaderNodeEmission")
    transparent = get("BSDF_TRANSPARENT") or nodes.new("ShaderNodeBsdfTransparent")
    mix = get("MIX_SHADER") or nodes.new("ShaderNodeMixShader")
    out = get("OUTPUT_MATERIAL") or nodes.new("ShaderNodeOutputMaterial")

    for l in list(links):
        if l.to_node == out and l.to_socket.name == "Surface":
            links.remove(l)

    links.new(image_node.outputs["Color"], emission.inputs["Color"])
    links.new(image_node.outputs["Alpha"], mix.inputs["Fac"])
    links.new(transparent.outputs["BSDF"], mix.inputs[1])
    links.new(emission.outputs["Emission"], mix.inputs[2])
    links.new(mix.outputs["Shader"], out.inputs["Surface"])

    mat.blend_method = "BLEND"
    return image_node


def unwrap_from_view(obj_name, camera_name):
    bpy.context.view_layer.objects.active = bpy.data.objects[obj_name]
    bpy.context.scene.camera = bpy.data.objects[camera_name]

    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')

    for window in bpy.context.window_manager.windows:
        screen = window.screen
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        context_override = bpy.context.copy()
                        override = {
                            'window': window,
                            'screen': screen,
                            'area': area,
                            'region': region,
                            'scene': bpy.context.scene,
                            'edit_object': bpy.context.edit_object,
                            'active_object': bpy.context.active_object,
                            'selected_objects': bpy.context.selected_objects,
                        }
                        context_override.update(override)
                        with bpy.context.temp_override(**context_override):
                            bpy.ops.uv.project_from_view(
                                camera_bounds=True,
                                correct_aspect=False,
                                scale_to_bounds=False,
                            )

    bpy.ops.object.mode_set(mode='OBJECT')


def render_still(cam, frame, path, output_format="PNG"):
    scene = bpy.context.scene
    prev_cam = scene.camera
    prev_fp = scene.render.filepath
    prev_fmt = scene.render.image_settings.file_format
    prev_mode = scene.render.image_settings.color_mode

    try:
        scene.camera = cam
        scene.frame_set(frame)
        scene.render.filepath = path
        if output_format == 'JPG':
            scene.render.image_settings.file_format = "JPEG"
            scene.render.image_settings.color_mode = "RGB"
        else:
            scene.render.image_settings.file_format = "PNG"
            scene.render.image_settings.color_mode = "RGBA"
        os.makedirs(os.path.dirname(path), exist_ok=True)
        bpy.ops.render.render(write_still=True)
    finally:
        scene.camera = prev_cam
        scene.render.filepath = prev_fp
        scene.render.image_settings.file_format = prev_fmt
        scene.render.image_settings.color_mode = prev_mode


def clear_vse(scene):
    if scene.sequence_editor:
        for s in list(scene.sequence_editor.sequences):
            try:
                scene.sequence_editor.sequences.remove(s)
            except Exception:
                pass


def run_generator(*args, **kwargs):
    """Wrapper that guarantees the temp projection folder is removed, even if
    the render is cancelled part-way through."""
    state = {}
    try:
        for step in _run_generator(state, *args, **kwargs):
            yield step
    finally:
        image_shrink.remove_temp_folder(state.get("temp_folder"))


def _run_generator(state, output_folder, start_frame, end_frame, output_format="PNG", codec="H264", format="MPEG4",
                   crf="MEDIUM", preset="GOOD", gop=12, video_bitrate=4500):
    frame_count = end_frame - start_frame + 1

    PROJ_CAMERA_NAME = "Camera3"
    FINAL_CAMERA_NAME = "Camera2"
    OBJECT_NAME = "SHEET"

    ext = ".png" if output_format == "PNG" else ".jpg"

    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    temp_folder = os.path.join(output_folder, "temp_proj")
    state["temp_folder"] = temp_folder

    if not os.path.exists(temp_folder):
        os.makedirs(temp_folder)

    scene = bpy.context.scene
    sheet_obj = bpy.data.objects.get(OBJECT_NAME)
    proj_cam = bpy.data.objects.get(PROJ_CAMERA_NAME)
    final_cam = bpy.data.objects.get(FINAL_CAMERA_NAME)
    scene_collection = bpy.data.collections.get("SCENE")

    if not sheet_obj or not proj_cam or not final_cam:
        raise RuntimeError("Missing Object or Camera (SHEET, Camera3, or Camera2)")

    image_shrink.focus_camera_and_sheet(PROJ_CAMERA_NAME, OBJECT_NAME)

    image_node = ensure_image_emission_nodes(sheet_obj)

    stopped = False

    for frame in range(start_frame, end_frame + 1):
        if scene.unchained_stop_render:
            print("Stop requested. Aborting single 3D render.")
            stopped = True
            break

        print(f"Rendering Frame {frame}...")
        scene.frame_set(frame)

        sheet_obj.hide_render = True
        if scene_collection:
            scene_collection.hide_render = False

        temp_path = os.path.join(temp_folder, f"proj_{frame:04d}.png")
        render_still(proj_cam, frame, temp_path, output_format=output_format)

        sheet_obj.hide_render = False

        try:
            loaded_img = None
            for im in bpy.data.images:
                if im.filepath == temp_path or os.path.abspath(bpy.path.abspath(im.filepath)) == os.path.abspath(temp_path):
                    loaded_img = im
                    break

            if loaded_img is None:
                loaded_img = bpy.data.images.load(temp_path)
            else:
                loaded_img.reload()

            image_node.image = loaded_img
        except Exception as e:
            print(f"Error loading temp image: {e}")

        unwrap_from_view(OBJECT_NAME, PROJ_CAMERA_NAME)

        if scene_collection:
            scene_collection.hide_render = True

        out_path = os.path.join(output_folder, f"RENDER_{frame:03d}{ext}")
        render_still(final_cam, frame, out_path, output_format=output_format)

        if scene_collection:
            scene_collection.hide_render = False
        sheet_obj.hide_render = True

        yield

    if image_node is not None:
        image_node.image = None

    image_shrink.remove_temp_folder(temp_folder)

    if stopped:
        return

    print("Frame Rendering Done.")

    print(f"Building MP4 in {output_folder}")

    if not scene.sequence_editor:
        scene.sequence_editor_create()

    clear_vse(scene)
    seq = scene.sequence_editor

    first_frame_name = f"RENDER_{start_frame:03d}{ext}"
    first_frame_path = os.path.join(output_folder, first_frame_name)

    if os.path.exists(first_frame_path):
        strip = seq.sequences.new_image(
            name="RenderedSequence",
            filepath=first_frame_path,
            channel=1,
            frame_start=1,
        )

        while len(strip.elements) > 0:
            try:
                strip.elements.remove(strip.elements[0])
            except Exception:
                break

        for i in range(start_frame, end_frame + 1):
            strip.elements.append(f"RENDER_{i:03d}{ext}")

        strip.frame_final_duration = frame_count

        scene.render.image_settings.file_format = "FFMPEG"
        scene.render.ffmpeg.format = format
        scene.render.ffmpeg.codec = codec
        scene.render.ffmpeg.constant_rate_factor = crf
        scene.render.ffmpeg.ffmpeg_preset = preset
        scene.render.ffmpeg.gopsize = gop
        scene.render.ffmpeg.video_bitrate = video_bitrate
        scene.render.ffmpeg.audio_codec = "NONE"

        scene.frame_start = 1
        scene.frame_end = frame_count

        out_mp4 = os.path.join(output_folder, "final_video.mp4")
        scene.render.filepath = out_mp4

        # Render the 2D VSE image sequence, NOT the 3D scene. Rendering the 3D
        # scene here makes Eevee re-sync the image-textured materials and can
        # crash (GPU_texture_free). Force the sequencer path.
        prev_use_seq = scene.render.use_sequencer
        prev_use_comp = scene.render.use_compositing
        prev_lock = scene.render.use_lock_interface
        scene.render.use_sequencer = True
        scene.render.use_compositing = False
        scene.render.use_lock_interface = True
        try:
            print(f"Rendering MP4 -> {out_mp4}")
            bpy.ops.render.render(animation=True)
        finally:
            scene.render.use_sequencer = prev_use_seq
            scene.render.use_compositing = prev_use_comp
            scene.render.use_lock_interface = prev_lock

        clear_vse(scene)
        print("MP4 Rendering Done.")
    else:
        print("Could not find first frame, skipping MP4 generation.")

    image_shrink.remove_temp_folder(temp_folder)
    image_shrink.shrink_folder(output_folder, recursive=True, skip_dirs=("temp_proj",))


def run(output_folder, start_frame, end_frame, output_format="PNG", codec="H264", format="MPEG4", crf="MEDIUM",
        preset="GOOD", gop=12, video_bitrate=4500):
    gen = run_generator(
        output_folder, start_frame, end_frame, output_format,
        codec, format, crf, preset, gop, video_bitrate,
    )
    try:
        while True:
            next(gen)
    except StopIteration:
        pass
