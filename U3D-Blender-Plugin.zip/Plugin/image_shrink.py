"""Post-render image optimisation.

Re-saves rendered images at the SAME resolution but with better compression so
the file size on disk shrinks. Uses Pillow when it is available inside Blender's
Python, otherwise falls back to Blender's own image save code.
"""

import os
import shutil
import time

import bpy

IMAGE_EXTS = ('.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp')

try:
    from PIL import Image
    HAS_PIL = True
except Exception:  # Pillow not bundled with this Blender build
    Image = None
    HAS_PIL = False


def _shrink_with_pil(path, jpg_quality):
    with Image.open(path) as img:
        fmt = (img.format or '').upper()
        img.load()
        ext = os.path.splitext(path)[1].lower()

        if ext in ('.jpg', '.jpeg') or fmt == 'JPEG':
            rgb = img.convert('RGB')
            rgb.save(path, 'JPEG', quality=jpg_quality, optimize=True, progressive=True)
        elif ext == '.png' or fmt == 'PNG':
            img.save(path, 'PNG', optimize=True, compress_level=9)
        elif ext == '.webp' or fmt == 'WEBP':
            img.save(path, 'WEBP', quality=jpg_quality, method=6)
        else:
            img.save(path, optimize=True)


def _shrink_with_bpy(path, jpg_quality):
    scene = bpy.context.scene
    settings = scene.render.image_settings

    prev_fmt = settings.file_format
    prev_mode = settings.color_mode
    prev_quality = settings.quality
    prev_compression = settings.compression

    img = bpy.data.images.load(path, check_existing=False)
    try:
        ext = os.path.splitext(path)[1].lower()
        if ext in ('.jpg', '.jpeg'):
            settings.file_format = 'JPEG'
            settings.color_mode = 'RGB'
            settings.quality = jpg_quality
        elif ext == '.png':
            settings.file_format = 'PNG'
            settings.color_mode = 'RGBA' if img.depth in (32, 64) else 'RGB'
            settings.compression = 100
        else:
            return
        img.save_render(filepath=path, scene=scene)
    finally:
        settings.file_format = prev_fmt
        settings.color_mode = prev_mode
        settings.quality = prev_quality
        settings.compression = prev_compression
        try:
            bpy.data.images.remove(img)
        except Exception:
            pass


def shrink_image(path, jpg_quality=85):
    """Re-save a single image at the same resolution with smaller file size."""
    try:
        before = os.path.getsize(path)
        if HAS_PIL:
            _shrink_with_pil(path, jpg_quality)
        else:
            _shrink_with_bpy(path, jpg_quality)
        after = os.path.getsize(path)
        if after > before:
            print(f"  Shrink: {os.path.basename(path)} grew, kept new file "
                  f"({before} -> {after} bytes)")
        else:
            print(f"  Shrunk: {os.path.basename(path)} {before} -> {after} bytes")
        return True
    except Exception as e:
        print(f"  Error shrinking '{path}': {e}")
        return False


def shrink_folder(folder, recursive=True, jpg_quality=85, skip_dirs=None):
    """Shrink every image in `folder` (in place, same resolution).

    skip_dirs: iterable of directory names to ignore (e.g. temp folders).
    """
    folder = os.path.abspath(folder)
    if not os.path.isdir(folder):
        print(f"Shrink skipped, folder not found: {folder}")
        return 0

    skip = set(skip_dirs or ())
    count = 0

    print(f"Shrinking images in: {folder} (Pillow: {HAS_PIL})")
    for root, dirs, files in os.walk(folder):
        dirs[:] = [d for d in dirs if d not in skip]
        for name in files:
            if name.lower().endswith(IMAGE_EXTS):
                if shrink_image(os.path.join(root, name), jpg_quality=jpg_quality):
                    count += 1
        if not recursive:
            break

    print(f"Shrink done. {count} image(s) processed.")
    return count


def purge_images_under(folder):
    """Drop any bpy images that were loaded from `folder` so it can be deleted."""
    folder = os.path.abspath(folder)
    for im in list(bpy.data.images):
        try:
            fp = os.path.abspath(bpy.path.abspath(im.filepath))
        except Exception:
            continue
        if fp and fp.startswith(folder + os.sep):
            try:
                bpy.data.images.remove(im)
            except Exception:
                pass


def remove_temp_folder(folder, retries=5, delay=0.3):
    """Delete a temp render folder and unload any images loaded from it.

    Retries because on Windows Blender may still hold file handles open for a
    moment after the images are unloaded.
    """
    if not folder or not os.path.isdir(folder):
        return

    print(f"Cleaning temp folder: {folder}")
    purge_images_under(folder)

    last_err = None
    for attempt in range(retries):
        try:
            shutil.rmtree(folder)
            print(f"Removed temp folder: {folder}")
            return
        except Exception as e:
            last_err = e
            time.sleep(delay)

    print(f"WARNING: could not remove temp folder '{folder}': {last_err}")


def focus_camera_and_sheet(camera_name, sheet_name="SHEET"):
    """Point every 3D viewport at `camera_name` and make SHEET the active/selected
    object, so users don't have to do this manually before a render."""
    scene = bpy.context.scene

    cam = bpy.data.objects.get(camera_name)
    if cam is not None:
        scene.camera = cam

    sheet = bpy.data.objects.get(sheet_name)
    if sheet is not None:
        for obj in bpy.data.objects:
            try:
                obj.select_set(False)
            except Exception:
                pass
        sheet.select_set(True)
        try:
            bpy.context.view_layer.objects.active = sheet
        except Exception:
            pass

    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                space = area.spaces.active
                rv3d = getattr(space, "region_3d", None)
                if rv3d is not None:
                    rv3d.view_perspective = 'CAMERA'

    print(f"View focused on camera '{camera_name}', SHEET selected.")


