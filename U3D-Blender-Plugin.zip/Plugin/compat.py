"""Blender version compatibility helpers (works on 3.x through 5.x)."""


def get_strips(seq_editor):
    """Return the sequencer strip collection for this Blender version.

    Blender 4.4+ / 5.x renamed ``sequence_editor.sequences`` to ``strips``.
    """
    if seq_editor is None:
        return None
    strips = getattr(seq_editor, "strips", None)
    if strips is not None:
        return strips
    return getattr(seq_editor, "sequences", None)


def new_image_strip(seq_editor, name, filepath, channel=1, frame_start=1):
    """Version-safe equivalent of ``sequence_editor.sequences.new_image``."""
    strips = get_strips(seq_editor)
    if strips is None:
        raise RuntimeError("No sequence editor / strips collection available.")
    return strips.new_image(
        name=name,
        filepath=filepath,
        channel=channel,
        frame_start=frame_start,
    )


def clear_vse(scene):
    """Remove every strip from the scene's sequence editor (version-safe)."""
    strips = get_strips(scene.sequence_editor)
    if strips is None:
        return
    for s in list(strips):
        try:
            strips.remove(s)
        except Exception:
            pass


def get_lock_interface(scene):
    """Return render.use_lock_interface, or None if it no longer exists."""
    return getattr(scene.render, "use_lock_interface", None)


def set_lock_interface(scene, value):
    """Set render.use_lock_interface if this Blender version still has it."""
    if value is None:
        return
    try:
        scene.render.use_lock_interface = value
    except (AttributeError, TypeError):
        pass


def set_blend_method(mat, value):
    """Set material.blend_method if it exists (removed in Blender 4.2+ EEVEE Next)."""
    try:
        mat.blend_method = value
    except (AttributeError, TypeError):
        pass
